/*import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final List<String> _messages = []; // Danh sách các tin nhắn

  // Hàm này sẽ được gọi khi người dùng gửi tin nhắn
  void _handleSubmitted(String text) {
    _textController.clear();
    setState(() {
      _messages.insert(0, "User: $text"); // Thêm tin nhắn của người dùng vào đầu danh sách
    });
    // TODO: Gửi tin nhắn đến API AI và nhận phản hồi
    _getAIResponse(text);
  }

  // Hàm này sẽ gọi API AI (cần cài đặt thêm logic)
  void _getAIResponse(String userMessage) async {
    // Đây là nơi bạn sẽ gọi API AI của dịch vụ bạn chọn
    // Ví dụ sử dụng một phản hồi giả định:
    await Future.delayed(const Duration(seconds: 1)); // Giả lập thời gian phản hồi của AI
    String aiResponse = "AI: Đây là phản hồi từ AI cho tin nhắn của bạn: '$userMessage'"; // Thay bằng phản hồi thực tế từ API

    setState(() {
      _messages.insert(0, aiResponse); // Thêm phản hồi của AI vào đầu danh sách
    });
  }

  Widget _buildTextComposer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Row(
        children: [
          Flexible(
            child: TextField(
              controller: _textController,
              onSubmitted: _handleSubmitted,
              decoration: const InputDecoration.collapsed(
                hintText: 'Nhập tin nhắn...',
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.send),
            onPressed: () => _handleSubmitted(_textController.text),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trò chuyện với AI'),
      ),
      body: Column(
        children: [
          Flexible(
            child: ListView.builder(
              padding: const EdgeInsets.all(8.0),
              reverse: true, // Hiển thị tin nhắn mới nhất ở dưới cùng
              itemCount: _messages.length,
              itemBuilder: (_, int index) => _buildMessage(_messages[index]),
            ),
          ),
          const Divider(height: 1.0),
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
            ),
            child: _buildTextComposer(),
          ),
        ],
      ),
    );
  }

  Widget _buildMessage(String message) {
    // Bạn có thể tùy chỉnh hiển thị tin nhắn của người dùng và AI ở đây
    bool isUserMessage = message.startsWith("User:");
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: isUserMessage ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          CircleAvatar(
            child: Text(isUserMessage ? 'Me' : 'AI'),
          ),
          const SizedBox(width: 8.0),
          Column(
            crossAxisAlignment: isUserMessage ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              Text(
                isUserMessage ? 'Bạn' : 'AI',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              Container(
                margin: const EdgeInsets.only(top: 5.0),
                child: Text(message.replaceFirst(isUserMessage ? "User:" : "AI:", "").trim()),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }
}*/
/*
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

// API KEY CỦA BẠN ĐÃ ĐƯỢC THÊM VÀO ĐÂY
const String apiKey = "AIzaSyAxqrgncesWu6IX0KzGg7GetXz2N6PK02o"; // <<<<<------ API KEY CỦA BẠN

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final List<Message> _messages = []; // Danh sách các tin nhắn kiểu Message
  late final GenerativeModel _model;
  late final ChatSession _chat;
  bool _isLoading = false; // Biến để theo dõi trạng thái loading

  @override
  void initState() {
    super.initState();
    _model = GenerativeModel(
      // Bạn có thể chọn 'gemini-pro' hoặc 'gemini-1.5-flash'
      // 'gemini-1.5-flash' nhanh hơn, 'gemini-pro' có thể mạnh hơn cho một số tác vụ
      model: 'gemini-1.5-flash',
      apiKey: apiKey,
      // Optional: Cấu hình an toàn
      // safetySettings: [
      //   SafetySetting(HarmCategory.harassment, HarmBlockThreshold.mediumAndAbove),
      //   SafetySetting(HarmCategory.hateSpeech, HarmBlockThreshold.mediumAndAbove),
      // ]
    );
    _chat = _model.startChat();
  }

  // Hàm này sẽ được gọi khi người dùng gửi tin nhắn
  void _handleSubmitted(String text) async {
    if (text.trim().isEmpty || _isLoading) return; // Không gửi nếu đang loading hoặc text rỗng

    final userMessageText = text.trim();
    _textController.clear();

    // Hiển thị tin nhắn người dùng ngay lập tức
    _addMessage(userMessageText, isUser: true);

    setState(() {
      _isLoading = true; // Bắt đầu loading
    });

    try {
      // Gửi tin nhắn đến API
      var response = await _chat.sendMessage(Content.text(userMessageText));
      var aiText = response.text;

      if (aiText == null || aiText.isEmpty) {
        _addMessage("Xin lỗi, tôi không thể tạo phản hồi lúc này.", isUser: false);
      } else {
        _addMessage(aiText, isUser: false);
      }
    } catch (e) {
      print('Lỗi khi gửi tin nhắn đến AI: $e');
      _addMessage("Đã xảy ra lỗi khi kết nối với AI. Vui lòng thử lại. Lỗi: ${e.toString()}", isUser: false);
    } finally {
      setState(() {
        _isLoading = false; // Kết thúc loading
      });
    }
  }

  // Hàm tiện ích để thêm tin nhắn vào danh sách và cập nhật UI
  void _addMessage(String text, {required bool isUser}) {
    setState(() {
      // Thêm tin nhắn vào đầu danh sách để hiển thị mới nhất ở dưới cùng khi reverse = true
      // Tuy nhiên, logic hiện tại của ListView.builder với reverse=true và index access
      // (_messages.length - 1 - index) thì nên add vào cuối và để reverse tự xử lý.
      _messages.add(Message(text: text, isUser: isUser));
    });
  }


  Widget _buildTextComposer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(25.0), // Bo tròn hơn
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 2),
            blurRadius: 5,
            color: Colors.grey.withOpacity(0.15),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              onSubmitted: _isLoading ? null : _handleSubmitted,
              decoration: const InputDecoration.collapsed(
                hintText: 'Nhập tin nhắn...',
              ),
              enabled: !_isLoading,
              minLines: 1,
              maxLines: 5, // Cho phép nhiều dòng hơn
              textInputAction: TextInputAction.send, // Thay đổi action button trên bàn phím
            ),
          ),
          IconButton(
            icon: _isLoading
                ? SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                  strokeWidth: 2.0,
                  valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
            )
                : Icon(Icons.send, color: Theme.of(context).primaryColor),
            onPressed: _isLoading || _textController.text.trim().isEmpty
                ? null
                : () => _handleSubmitted(_textController.text),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trò chuyện với Gemini'),
        elevation: 1.0, // Thêm chút đổ bóng cho AppBar
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              reverse: true, // Tin nhắn mới nhất ở dưới cùng
              itemCount: _messages.length,
              itemBuilder: (_, int index) {
                // Khi reverse: true, item đầu tiên trong builder (index 0) là item cuối cùng của list
                // và item cuối cùng trong builder (index _messages.length -1) là item đầu tiên của list.
                // Để hiển thị đúng thứ tự từ _messages (cũ nhất -> mới nhất)
                // và ListView hiển thị (mới nhất -> cũ nhất từ dưới lên),
                // chúng ta cần truy cập _messages[_messages.length - 1 - index].
                final message = _messages[_messages.length - 1 - index];
                return _buildMessage(message);
              },
            ),
          ),
          const Divider(height: 1.0),
          SafeArea( // Đảm bảo phần nhập liệu không bị che bởi các phần tử hệ thống (ví dụ: home indicator trên iOS)
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8.0, left: 8.0, right: 8.0, top:4.0),
              child: _buildTextComposer(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessage(Message message) {
    // Căn chỉnh tin nhắn của người dùng sang phải, AI sang trái
    final alignment = message.isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final backgroundColor = message.isUser
        ? Theme.of(context).primaryColor.withOpacity(0.9)
        : Colors.grey[200];
    final textColor = message.isUser ? Colors.white : Colors.black87;
    final avatar = message.isUser
        ? CircleAvatar(
      backgroundColor: Theme.of(context).colorScheme.secondary,
      child: const Text('Me', style: TextStyle(color: Colors.white, fontSize: 12)),
    )
        : CircleAvatar(
      backgroundColor: Colors.grey[400],
      child: const Text('AI', style: TextStyle(color: Colors.white, fontSize: 12)),
    );

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6.0), // Giảm khoảng cách dọc một chút
      child: Row(
        mainAxisAlignment: message.isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end, // Căn avatar với cuối của bubble chat
        children: [
          if (!message.isUser) avatar,
          if (!message.isUser) const SizedBox(width: 8.0),
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 10.0), // Tăng padding
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18.0),
                  topRight: const Radius.circular(18.0),
                  bottomLeft: message.isUser ? const Radius.circular(18.0) : const Radius.circular(0),
                  bottomRight: message.isUser ? const Radius.circular(0) : const Radius.circular(18.0),
                ),
              ),
              child: Text(
                message.text,
                style: TextStyle(color: textColor, fontSize: 15.0), // Tăng kích thước chữ một chút
              ),
            ),
          ),
          if (message.isUser) const SizedBox(width: 8.0),
          if (message.isUser) avatar,
        ],
      ),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }
}

// Lớp để biểu diễn một tin nhắn
class Message {
  final String text;
  final bool isUser;

  Message({required this.text, required this.isUser});
}*/
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

// API KEY CỦA BẠN ĐÃ ĐƯỢC THÊM VÀO ĐÂY
const String apiKey = "AIzaSyAxqrgncesWu6IX0KzGg7GetXz2N6PK02o"; // <<<<<------ API KEY CỦA BẠN (NHỚ BẢO MẬT KEY NÀY)

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController(); // Để tự động cuộn xuống
  final List<Message> _messages = [];
  late final GenerativeModel _model;
  late final ChatSession _chat;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _model = GenerativeModel(
      model: 'gemini-1.5-flash', // Hoặc 'gemini-pro'
      apiKey: apiKey,
    );
    _chat = _model.startChat();
  }

  void _scrollToBottom() {
    // Đảm bảo widget đã được build và có vị trí
    if (_scrollController.hasClients) {
      // Đợi một chút để ListView cập nhật xong rồi mới cuộn
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollController.animateTo(
          _scrollController.position.minScrollExtent, // Cuộn xuống dưới cùng khi reverse = true
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  void _handleSubmitted(String text) async {
    if (text.trim().isEmpty || _isLoading) return;

    final userMessageText = text.trim();
    _textController.clear();

    _addMessage(userMessageText, isUser: true, isLoading: false);
    _scrollToBottom(); // Cuộn xuống sau khi thêm tin nhắn người dùng

    setState(() {
      _isLoading = true;
      // Thêm một tin nhắn "AI đang nhập..." tạm thời (tùy chọn)
      // _addMessage("...", isUser: false, isLoading: true);
      // _scrollToBottom();
    });

    try {
      var response = await _chat.sendMessage(Content.text(userMessageText));
      var aiText = response.text;

      // Xóa tin nhắn "AI đang nhập..." nếu có
      // _removeLoadingMessage();

      if (aiText == null || aiText.isEmpty) {
        _addMessage("Xin lỗi, tôi không thể tạo phản hồi lúc này.", isUser: false, isLoading: false);
      } else {
        _addMessage(aiText, isUser: false, isLoading: false);
      }
    } catch (e) {
      print('Lỗi khi gửi tin nhắn đến AI: $e');
      // _removeLoadingMessage(); // Xóa tin nhắn "AI đang nhập..." nếu có lỗi
      _addMessage("Đã xảy ra lỗi: ${e.toString().substring(0, (e.toString().length > 100) ? 100 : e.toString().length)}...", isUser: false, isLoading: false);
    } finally {
      setState(() {
        _isLoading = false;
      });
      _scrollToBottom(); // Cuộn xuống sau khi AI trả lời
    }
  }

  void _addMessage(String text, {required bool isUser, required bool isLoading}) {
    setState(() {
      _messages.add(Message(text: text, isUser: isUser, isLoading: isLoading));
    });
  }

  // Hàm để xóa tin nhắn loading (nếu bạn sử dụng)
  // void _removeLoadingMessage() {
  //   setState(() {
  //     _messages.removeWhere((msg) => msg.isLoading && !msg.isUser);
  //   });
  // }


  Widget _buildTextComposer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      padding: const EdgeInsets.symmetric(horizontal: 8.0), // Giảm padding ngang một chút
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(30.0), // Bo tròn nhiều hơn
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 3),
            blurRadius: 6,
            color: Colors.black.withOpacity(0.08), // Đổ bóng nhẹ hơn
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0), // Thêm padding cho TextField
              child: TextField(
                controller: _textController,
                onSubmitted: _isLoading ? null : _handleSubmitted,
                decoration: const InputDecoration.collapsed(
                  hintText: 'Nhắn tin cho Gemini...',
                  hintStyle: TextStyle(fontSize: 15),
                ),
                style: const TextStyle(fontSize: 15),
                enabled: !_isLoading,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.send,
              ),
            ),
          ),
          IconButton(
            icon: _isLoading
                ? SizedBox(
              width: 22, // Giảm kích thước một chút
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2.0,
                valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
              ),
            )
                : Icon(Icons.send_rounded, color: Theme.of(context).primaryColor, size: 26), // Icon bo tròn và to hơn
            onPressed: _isLoading || _textController.text.trim().isEmpty
                ? null
                : () => _handleSubmitted(_textController.text),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat với Gemini', style: TextStyle(fontWeight: FontWeight.w500)),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor, // Đồng bộ màu nền
        elevation: 0.5, // Giảm độ nổi của AppBar
        centerTitle: true,
      ),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController, // Gán ScrollController
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0), // Tăng padding tổng thể
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (_, int index) {
                final message = _messages[_messages.length - 1 - index];
                // Sử dụng key để giúp Flutter nhận diện item tốt hơn khi có thay đổi (tùy chọn)
                return _buildMessage(message, key: ValueKey(_messages.length - 1 - index));
              },
            ),
          ),
          const Divider(height: 0.5, thickness: 0.5), // Mỏng hơn
          SafeArea(
            child: Padding(
              // Điều chỉnh padding cho vùng nhập liệu để cân đối hơn
              padding: const EdgeInsets.only(bottom: 8.0, left: 4.0, right: 4.0, top: 4.0),
              child: _buildTextComposer(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessage(Message message, {Key? key}) {
    final bool isUserMessage = message.isUser;
    final bool isMessageLoading = message.isLoading; // Kiểm tra tin nhắn loading

    // Màu sắc và bo góc
    final Color bubbleColor = isUserMessage
        ? Theme.of(context).primaryColor // Màu chính cho người dùng
        : Theme.of(context).colorScheme.surfaceVariant; // Màu nền nhẹ cho AI
    final Color textColor = isUserMessage
        ? Colors.white
        : Theme.of(context).colorScheme.onSurfaceVariant;
    final BorderRadius borderRadius = BorderRadius.only(
      topLeft: const Radius.circular(20.0),
      topRight: const Radius.circular(20.0),
      bottomLeft: isUserMessage ? const Radius.circular(20.0) : const Radius.circular(4.0), // Ít bo hơn ở góc dưới bên trái của AI
      bottomRight: isUserMessage ? const Radius.circular(4.0) : const Radius.circular(20.0), // Ít bo hơn ở góc dưới bên phải của người dùng
    );

    Widget messageContent;
    if (isMessageLoading) {
      messageContent = SizedBox(
        width: 50, // Chiều rộng cho hiệu ứng loading
        height: 20, // Chiều cao
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(3, (index) =>
              CircleAvatar(
                  radius: 4,
                  backgroundColor: textColor.withOpacity(0.5)
              )
          ),
        ),
      );
    } else {
      messageContent = Text(
        message.text,
        style: TextStyle(color: textColor, fontSize: 15.5, height: 1.3), // Tăng nhẹ line height
      );
    }


    return Container(
      key: key,
      padding: const EdgeInsets.symmetric(vertical: 6.0), // Giảm khoảng cách dọc để gần hơn
      child: Row(
        mainAxisAlignment: isUserMessage ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUserMessage)
            Padding(
              padding: const EdgeInsets.only(right: 8.0, bottom: 2.0), // Điều chỉnh vị trí avatar AI
              child: CircleAvatar(
                backgroundColor: Colors.grey[300],
                child: const Icon(Icons.psychology_outlined, size: 20, color: Colors.black54), // Icon AI
              ),
            ),
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75), // Giới hạn chiều rộng bong bóng
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0), // Tăng padding bên trong
              decoration: BoxDecoration(
                color: bubbleColor,
                borderRadius: borderRadius,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05), // Đổ bóng rất nhẹ
                    spreadRadius: 0.5,
                    blurRadius: 3,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: messageContent,
            ),
          ),
          if (isUserMessage)
            Padding(
              padding: const EdgeInsets.only(left: 8.0, bottom: 2.0), // Điều chỉnh vị trí avatar User
              child: CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.secondaryContainer,
                child: Text(
                  'Me',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onSecondaryContainer,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose(); // Nhớ dispose ScrollController
    super.dispose();
  }
}

// Lớp để biểu diễn một tin nhắn
class Message {
  final String text;
  final bool isUser;
  final bool isLoading; // Thêm thuộc tính này

  Message({required this.text, required this.isUser, this.isLoading = false}); // Giá trị mặc định là false
}