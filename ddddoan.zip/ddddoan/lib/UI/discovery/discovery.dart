/*import 'package:flutter/material.dart';

class DiscoveryTab extends StatelessWidget {
  const DiscoveryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Discovery Tab'),
      ),
    );
  }
}*/
/*
import 'package:flutter/material.dart';

class DiscoveryTab extends StatelessWidget {
  const DiscoveryTab({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tìm kiếm'),
        // Thanh tìm kiếm ở AppBar
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Bạn muốn nghe gì...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                filled: true,
                fillColor: Colors.blueGrey[200],
              ),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Tiêu đề "Thể loại"
              const Text(
                'Genres',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              // Danh sách thể loại (ví dụ)
              SizedBox(
                height: 50, // Điều chỉnh chiều cao tùy ý
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _GenreButton(genre: 'Pop'),
                    _GenreButton(genre: 'Rock'),
                    _GenreButton(genre: 'EDM'),
                    _GenreButton(genre: 'Jazz'),
                    _GenreButton(genre: 'Country'),
                    _GenreButton(genre: 'Hip Hop'),
                    _GenreButton(genre: 'Kpop'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Tiêu đề "Bài hát nổi bật"
              const Text(
                'Trending Songs',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              // Danh sách bài hát nổi bật (ví dụ)
              Column(
                children: const [
                  _SongTile(songName: 'Đế Vương', artistName: 'Đình Dũng'),
                  _SongTile(songName: 'Where Have You Gone', artistName: 'Ricky J'),
                  _SongTile(songName: 'Lắng Nghe Nước Mắt', artistName: 'Mr.Siro'),
                  _SongTile(songName: 'Beautiful In White', artistName: 'Shayne Ward'),
                ],
              ),
              const SizedBox(height: 20),
              // Tiêu đề "Playlists"
              const Text(
                'Playlists',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Column(
                children: const [
                  _PlaylistTile(playlistName: 'Playlist 1', numberOfSong: 10, image: ''),
                  _PlaylistTile(playlistName: 'Playlist 2', numberOfSong: 15, image: ''),
                  _PlaylistTile(playlistName: 'Playlist 3', numberOfSong: 20, image: ''),
                  _PlaylistTile(playlistName: 'Playlist 4', numberOfSong: 5, image: ''),
                ],
              ),
              const SizedBox(height: 20),
              // Tiêu đề "Nghệ sĩ nổi bật"
              const Text(
                'Trending Artists',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              // Danh sách nghệ sĩ nổi bật (ví dụ)
              SizedBox(
                height: 100, // Điều chỉnh chiều cao tùy ý
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _ArtistCircle(artistName: 'Đế Vương', image: 'https://thantrieu.com/resources/arts/1073969323.webp'),
                    _ArtistCircle(artistName: 'Where Have You Gone', image: 'assets/artist2.jpg'),
                    _ArtistCircle(artistName: 'Lắng Nghe ', image: 'assets/artist3.jpg'),
                    _ArtistCircle(artistName: 'Artist D', image: 'assets/artist4.jpg'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Widget con cho nút thể loại
class _GenreButton extends StatelessWidget {
  final String genre;

  const _GenreButton({required this.genre});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: ElevatedButton(
        onPressed: () {
          // Xử lý khi nhấn vào thể loại
          print('Selected genre: $genre');
        },
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        child: Text(genre),
      ),
    );
  }
}

// Widget con cho mỗi bài hát trong danh sách bài hát nổi bật
class _SongTile extends StatelessWidget {
  final String songName;
  final String artistName;

  const _SongTile({required this.songName, required this.artistName});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.music_note),
      title: Text(songName),
      subtitle: Text(artistName),
      trailing: IconButton(
        icon: const Icon(Icons.more_vert),
        onPressed: () {
          // Xử lý khi nhấn vào nút more
        },
      ),
    );
  }
}

class _PlaylistTile extends StatelessWidget {
  final String playlistName;
  final int numberOfSong;
  final String image;

  const _PlaylistTile({required this.playlistName, required this.numberOfSong, required this.image});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.asset(
          image,
          width: 48,
          height: 48,
          fit: BoxFit.cover,
        ),
      ),
      title: Text(playlistName),
      subtitle: Text('$numberOfSong songs'),
      trailing: const Icon(Icons.play_circle_outline),
      onTap: () {
        // Xử lý khi nhấn vào nút play
      },
    );
  }
}

// Widget con cho vòng tròn nghệ sĩ
class _ArtistCircle extends StatelessWidget {
  final String artistName;
  final String image;

  const _ArtistCircle({required this.artistName, required this.image});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: Column(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundImage: AssetImage(image),
          ),
          const SizedBox(height: 5),
          Text(artistName),
        ],
      ),
    );
  }
}*//*
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // Import package http
import 'dart:convert'; // Import dart:convert để làm việc với JSON

// Giả sử bạn đã tạo file song.dart như hướng dẫn ở trên
import '/data/model/song.dart'; // Import model Song

class DiscoveryTab extends StatefulWidget {
  const DiscoveryTab({super.key});

  @override
  State<DiscoveryTab> createState() => _DiscoveryTabState();
}

class _DiscoveryTabState extends State<DiscoveryTab> {
  final TextEditingController _searchController = TextEditingController();
  List<Song> _allSongs = []; // Danh sách tất cả bài hát
  List<Song> _displayedSongs = []; // Danh sách bài hát hiển thị (sau khi tìm kiếm)
  bool _isLoading = true; // Trạng thái tải dữ liệu
  String _errorMessage = ''; // Thông báo lỗi nếu có

  // URL danh sách bài hát của bạn
  final String songsUrl = 'https://thantrieu.com/resources/braniumapis/songs.json';

  @override
  void initState() {
    super.initState();
    _fetchSongs(); // Tải danh sách bài hát khi widget được khởi tạo
    _searchController.addListener(_onSearchChanged); // Lắng nghe thay đổi trong ô tìm kiếm
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchSongs() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final response = await http.get(Uri.parse(songsUrl));
      if (response.statusCode == 200) {
        // UTF-8 decode nếu cần, API này có vẻ trả về JSON thuần
        final bodyContent = utf8.decode(response.bodyBytes);
        // JSON từ URL này có cấu trúc {"songs": [...]}
        final Map<String, dynamic> jsonData = json.decode(bodyContent);
        final List<dynamic> songListJson = jsonData['songs'] as List<dynamic>;

        if (mounted) { // Kiểm tra widget có còn trong tree không
          setState(() {
            _allSongs = songListJson.map((jsonItem) => Song.fromJson(jsonItem as Map<String, dynamic>)).toList();
            _displayedSongs = List.from(_allSongs); // Ban đầu hiển thị tất cả bài hát
            _isLoading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _errorMessage = 'Lỗi tải dữ liệu: ${response.statusCode}';
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        print('Lỗi khi fetch songs: $e');
        setState(() {
          _errorMessage = 'Đã xảy ra lỗi: $e';
          _isLoading = false;
        });
      }
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();
    if (query.isEmpty) {
      setState(() {
        _displayedSongs = List.from(_allSongs); // Hiển thị lại tất cả nếu ô tìm kiếm trống
      });
    } else {
      setState(() {
        _displayedSongs = _allSongs.where((song) {
          final titleLower = song.title.toLowerCase();
          final artistLower = song.artist.toLowerCase();
          return titleLower.contains(query) || artistLower.contains(query);
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tìm kiếm & Khám phá'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60.0), // Tăng chiều cao một chút
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0), // Điều chỉnh padding
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Tìm bài hát, nghệ sĩ...',
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0), // Bo tròn hơn
                  borderSide: BorderSide.none, // Bỏ viền
                ),
                filled: true,
                fillColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.grey[800]
                    : Colors.grey[200], // Màu nền dựa trên theme
                contentPadding: const EdgeInsets.symmetric(vertical: 0), // Căn giữa nội dung
              ),
            ),
          ),
        ),
      ),
      body: _buildBody(), // Xây dựng phần thân dựa trên trạng thái
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_errorMessage, style: const TextStyle(color: Colors.red, fontSize: 16)),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('Thử lại'),
                onPressed: _fetchSongs,
              )
            ],
          ),
        ),
      );
    }

    // Nếu không có tìm kiếm, hiển thị giao diện khám phá ban đầu
    // Nếu có tìm kiếm (và có kết quả hoặc không có kết quả), hiển thị kết quả tìm kiếm
    final bool isSearching = _searchController.text.isNotEmpty;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Chỉ hiển thị phần "Thể loại", "Playlists", "Nghệ sĩ nổi bật"
          // nếu người dùng không đang tìm kiếm
          if (!isSearching) ...[
            _buildSectionTitle('Thể loại'),
            const SizedBox(height: 10),
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  _GenreButton(genre: 'Pop'),
                  _GenreButton(genre: 'Rock'),
                  _GenreButton(genre: 'EDM'),
                  _GenreButton(genre: 'Jazz'),
                  // Thêm các thể loại khác
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildSectionTitle('Playlists Nổi Bật'),
            const SizedBox(height: 10),
            Column(
              children: const [
                // Sử dụng _PlaylistTile đã có
                // Bạn có thể fetch dữ liệu playlist tương tự như songs
                _PlaylistTile(playlistName: 'Top Hits Việt Nam', numberOfSong: 50, imagePath: 'assets/playlist_placeholder.png'),
                _PlaylistTile(playlistName: 'Chill Cùng Đêm Mưa', numberOfSong: 30, imagePath: 'assets/playlist_placeholder.png'),
              ],
            ),
            const SizedBox(height: 20),
            _buildSectionTitle('Nghệ sĩ Thịnh Hành'),
            const SizedBox(height: 10),
            SizedBox(
              height: 120, // Tăng chiều cao một chút
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  // Sử dụng _ArtistCircle đã có
                  // Bạn cũng có thể fetch dữ liệu nghệ sĩ
                  _ArtistCircle(artistName: 'Sơn Tùng M-TP', imagePath: 'assets/artist_placeholder.png'),
                  _ArtistCircle(artistName: 'AMEE', imagePath: 'assets/artist_placeholder.png'),
                  _ArtistCircle(artistName: 'Hoàng Dũng', imagePath: 'assets/artist_placeholder.png'),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // Luôn hiển thị tiêu đề "Bài hát" hoặc "Kết quả tìm kiếm"
          _buildSectionTitle(isSearching ? 'Kết quả tìm kiếm (${_displayedSongs.length})' : 'Bài hát cho bạn'),
          const SizedBox(height: 10),

          if (_displayedSongs.isEmpty && isSearching)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: Text('Không tìm thấy bài hát nào.', style: TextStyle(fontSize: 16, color: Colors.grey)),
              ),
            )
          else if (_displayedSongs.isEmpty && !isSearching)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: Text('Không có bài hát nào để hiển thị.', style: TextStyle(fontSize: 16, color: Colors.grey)),
              ),
            )
          else
          // Hiển thị danh sách bài hát (kết quả tìm kiếm hoặc tất cả)
            ListView.builder(
              shrinkWrap: true, // Quan trọng khi ListView nằm trong SingleChildScrollView
              physics: const NeverScrollableScrollPhysics(), // Để SingleChildScrollView xử lý cuộn
              itemCount: _displayedSongs.length,
              itemBuilder: (context, index) {
                final song = _displayedSongs[index];
                return _SongTile(
                  song: song, // Truyền cả đối tượng Song
                  onTap: () {
                    // Xử lý khi nhấn vào bài hát, ví dụ: phát nhạc
                    print('Playing: ${song.title} - ${song.artist}');
                    // Bạn có thể điều hướng đến màn hình phát nhạc ở đây
                  },
                );
              },
            ),
          const SizedBox(height: 20), // Khoảng trống ở cuối
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 22, // Tăng kích thước
        fontWeight: FontWeight.bold,
        color: Colors.black87, // Màu chữ rõ ràng hơn
      ),
    );
  }
}

// --- CÁC WIDGET CON (Đã điều chỉnh một chút) ---

class _GenreButton extends StatelessWidget {
  final String genre;
  const _GenreButton({required this.genre});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0), // Chỉ cần padding bên phải
      child: ActionChip( // Sử dụng ActionChip cho giao diện đẹp hơn
        label: Text(genre, style: const TextStyle(fontWeight: FontWeight.w500)),
        onPressed: () {
          print('Selected genre: $genre');
          // TODO: Lọc bài hát theo thể loại nếu cần
        },
        backgroundColor: Colors.blueGrey[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
      ),
    );
  }
}

// Sửa đổi _SongTile để nhận đối tượng Song và hiển thị ảnh (nếu có)
class _SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback? onTap; // Thêm callback khi nhấn vào

  const _SongTile({required this.song, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 0), // Điều chỉnh padding
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8.0),
        child: FadeInImage.assetNetwork( // Hiển thị ảnh với placeholder
          placeholder: 'assets/music_placeholder.png', // **BẠN CẦN THÊM ẢNH NÀY VÀO ASSETS**
          image: song.image,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
          imageErrorBuilder: (context, error, stackTrace) {
            return Image.asset('assets/music_placeholder.png', width: 50, height: 50, fit: BoxFit.cover);
          },
        ),
      ),
      title: Text(song.title, style: const TextStyle(fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis,),
      subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis,),
      trailing: IconButton(
        icon: const Icon(Icons.more_vert_rounded),
        onPressed: () {
          // Xử lý menu ngữ cảnh cho bài hát
        },
      ),
      onTap: onTap, // Gọi callback khi nhấn
    );
  }
}

// Sửa đổi _PlaylistTile để sử dụng imagePath và xử lý lỗi ảnh
class _PlaylistTile extends StatelessWidget {
  final String playlistName;
  final int numberOfSong;
  final String imagePath; // Sử dụng imagePath cho ảnh từ assets

  const _PlaylistTile({required this.playlistName, required this.numberOfSong, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Card( // Bọc trong Card để có hiệu ứng nổi và bo góc đẹp hơn
      elevation: 1,
      margin: const EdgeInsets.symmetric(vertical: 6.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: Image.asset( // Sử dụng Image.asset
            imagePath, // **ĐẢM BẢO BẠN CÓ ẢNH NÀY TRONG ASSETS**
            width: 55,
            height: 55,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) { // Xử lý nếu ảnh không tải được
              return Container(
                width: 55,
                height: 55,
                color: Colors.grey[300],
                child: const Icon(Icons.broken_image, color: Colors.grey),
              );
            },
          ),
        ),
        title: Text(playlistName, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('$numberOfSong bài hát'),
        trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey[600]), // Icon điều hướng
        onTap: () {
          print('Selected playlist: $playlistName');
          // Điều hướng đến màn hình chi tiết playlist
        },
      ),
    );
  }
}

// Sửa đổi _ArtistCircle để sử dụng imagePath và xử lý lỗi ảnh
class _ArtistCircle extends StatelessWidget {
  final String artistName;
  final String imagePath; // Sử dụng imagePath

  const _ArtistCircle({required this.artistName, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Container( // Bọc trong Container để dễ dàng style
      width: 90, // Set chiều rộng cố định
      margin: const EdgeInsets.only(right: 12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 38, // Giảm kích thước một chút
            backgroundColor: Colors.grey[300], // Màu nền nếu ảnh lỗi
            backgroundImage: AssetImage(imagePath), // **ĐẢM BẢO CÓ ẢNH NÀY TRONG ASSETS**
            onBackgroundImageError: (exception, stackTrace) { // Xử lý lỗi ảnh nền
              print('Error loading artist image: $artistName, $exception');
            },
            child: (imagePath.isEmpty || Uri.tryParse(imagePath)?.isAbsolute != true && !imagePath.startsWith('assets/')) // Kiểm tra nếu là URL hợp lệ hoặc asset path
                ? const Icon(Icons.person, size: 30, color: Colors.white) // Icon mặc định nếu ảnh lỗi/trống
                : null,
          ),
          const SizedBox(height: 8),
          Text(
            artistName,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}*/
// discovery.dart

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Import model Song (đảm bảo đường dẫn chính xác)
import "/data/model/song.dart"; // <<--- THAY ĐỔI ĐƯỜNG DẪN NÀY

// Import màn hình Nowplaying (đảm bảo đường dẫn chính xác)
import '/UI/now_playing/playing.dart'; // <<--- THAY ĐỔI ĐƯỜNG DẪN NÀY

class DiscoveryTab extends StatefulWidget {
  const DiscoveryTab({super.key});

  @override
  State<DiscoveryTab> createState() => _DiscoveryTabState();
}

class _DiscoveryTabState extends State<DiscoveryTab> {
  final TextEditingController _searchController = TextEditingController();
  List<Song> _allSongs = [];
  List<Song> _displayedSongs = [];
  bool _isLoading = true;
  String _errorMessage = '';

  final String songsUrl = 'https://thantrieu.com/resources/braniumapis/songs.json';

  @override
  void initState() {
    super.initState();
    _fetchSongs();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchSongs() async {
    // ... (Giữ nguyên code _fetchSongs của bạn) ...
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final response = await http.get(Uri.parse(songsUrl));
      if (response.statusCode == 200) {
        final bodyContent = utf8.decode(response.bodyBytes);
        final Map<String, dynamic> jsonData = json.decode(bodyContent);
        final List<dynamic> songListJson = jsonData['songs'] as List<dynamic>;

        if (mounted) {
          setState(() {
            _allSongs = songListJson.map((jsonItem) => Song.fromJson(jsonItem as Map<String, dynamic>)).toList();
            // Ban đầu, nếu không tìm kiếm, có thể hiển thị một phần của _allSongs hoặc để trống
            // Nếu bạn muốn hiển thị tất cả ngay từ đầu:
            _displayedSongs = List.from(_allSongs);
            _isLoading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _errorMessage = 'Lỗi tải dữ liệu: ${response.statusCode}';
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        print('Lỗi khi fetch songs: $e');
        setState(() {
          _errorMessage = 'Đã xảy ra lỗi: $e';
          _isLoading = false;
        });
      }
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();
    if (query.isEmpty) {
      setState(() {
        // Khi ô tìm kiếm trống, quyết định hiển thị gì.
        // Có thể là danh sách gợi ý, hoặc không hiển thị gì cả cho đến khi có kết quả
        // Hoặc hiển thị lại một phần của _allSongs nếu đó là mong muốn.
        // Hiện tại: hiển thị lại tất cả bài hát nếu ô tìm kiếm trống
        _displayedSongs = List.from(_allSongs);
      });
    } else {
      setState(() {
        _displayedSongs = _allSongs.where((song) {
          final titleLower = song.title.toLowerCase();
          final artistLower = song.artist.toLowerCase();
          return titleLower.contains(query) || artistLower.contains(query);
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // ... (Giữ nguyên phần AppBar của bạn) ...
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tìm kiếm & Khám phá'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60.0),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Tìm bài hát, nghệ sĩ...',
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.grey[800]
                    : Colors.grey[200],
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    // ... (Giữ nguyên phần kiểm tra _isLoading và _errorMessage) ...
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_errorMessage, style: const TextStyle(color: Colors.red, fontSize: 16)),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('Thử lại'),
                onPressed: _fetchSongs,
              )
            ],
          ),
        ),
      );
    }

    final bool isSearching = _searchController.text.isNotEmpty;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isSearching) ...[
            _buildSectionTitle('Thể loại'),
            const SizedBox(height: 10),
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  _GenreButton(genre: 'Pop'),
                  _GenreButton(genre: 'Rock'),
                  _GenreButton(genre: 'EDM'),
                  _GenreButton(genre: 'Jazz'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildSectionTitle('Playlists Nổi Bật'),
            const SizedBox(height: 10),
            Column(
              children: const [
                _PlaylistTile(playlistName: 'Top Hits Việt Nam', numberOfSong: 50, imagePath: 'assets/playlist_placeholder.png'),
                _PlaylistTile(playlistName: 'Chill Cùng Đêm Mưa', numberOfSong: 30, imagePath: 'assets/playlist_placeholder.png'),
              ],
            ),
            const SizedBox(height: 20),
            _buildSectionTitle('Nghệ sĩ Thịnh Hành'),
            const SizedBox(height: 10),
            SizedBox(
              height: 120,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  _ArtistCircle(artistName: 'Sơn Tùng M-TP', imagePath: 'assets/artist_placeholder.png'),
                  _ArtistCircle(artistName: 'AMEE', imagePath: 'assets/artist_placeholder.png'),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          _buildSectionTitle(isSearching ? 'Kết quả tìm kiếm (${_displayedSongs.length})' : 'Bài hát cho bạn'),
          const SizedBox(height: 10),

          if (_displayedSongs.isEmpty && isSearching)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: Text('Không tìm thấy bài hát nào.', style: TextStyle(fontSize: 16, color: Colors.grey)),
              ),
            )
          else if (_displayedSongs.isEmpty && !isSearching && _allSongs.isNotEmpty) // Chỉ hiển thị nếu _allSongs có dữ liệu nhưng _displayedSongs trống (ít xảy ra với logic hiện tại)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: Text('Không có bài hát nào để hiển thị.', style: TextStyle(fontSize: 16, color: Colors.grey)),
              ),
            )
          else if (_allSongs.isEmpty && !isSearching) // Nếu chưa tải xong _allSongs và không tìm kiếm
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20.0),
                  child: Text('Đang tải danh sách bài hát...', style: TextStyle(fontSize: 16, color: Colors.grey)),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _displayedSongs.length,
                itemBuilder: (context, index) {
                  final song = _displayedSongs[index];
                  return _SongTile(
                    song: song,
                    onTap: () {
                      print('Đã chọn bài hát: ${song.title}');
                      // Danh sách bài hát để truyền vào Nowplaying có thể là _displayedSongs
                      // nếu bạn muốn danh sách phát dựa trên kết quả tìm kiếm hiện tại,
                      // hoặc _allSongs nếu bạn muốn danh sách phát luôn là tất cả bài hát.
                      // Ở đây, chúng ta dùng _allSongs để có trải nghiệm next/prev qua tất cả bài hát.
                      if (_allSongs.isNotEmpty) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Nowplaying(
                              songs: _allSongs, // Truyền toàn bộ danh sách bài hát
                              playingSong: song, // Bài hát được chọn để phát
                            ),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Danh sách bài hát chưa sẵn sàng.')),
                        );
                      }
                    },
                  );
                },
              ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    // ... (Giữ nguyên code _buildSectionTitle của bạn) ...
    return Text(
      title,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
      ),
    );
  }
}

// --- CÁC WIDGET CON (_GenreButton, _SongTile, _PlaylistTile, _ArtistCircle) ---
// ... (Giữ nguyên code các widget con của bạn) ...
// Đảm bảo _SongTile có onTap callback
class _GenreButton extends StatelessWidget {
  final String genre;
  const _GenreButton({required this.genre});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: ActionChip(
        label: Text(genre, style: const TextStyle(fontWeight: FontWeight.w500)),
        onPressed: () {
          print('Selected genre: $genre');
        },
        backgroundColor: Colors.blueGrey[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
      ),
    );
  }
}

class _SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback? onTap;

  const _SongTile({super.key, required this.song, this.onTap}); // Sửa key

  @override
  Widget build(BuildContext context) {
    // Sử dụng Hero với tag duy nhất nếu bạn muốn có animation chuyển ảnh
    // final heroTag = 'songImage_${song.id}_from_discovery';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 0),
      leading: /*Hero( // Bỏ comment nếu muốn dùng Hero
        tag: heroTag,
        child:*/ ClipRRect(
        borderRadius: BorderRadius.circular(8.0),
        child: FadeInImage.assetNetwork(
          placeholder: 'assets/music_placeholder.png', // **NHỚ THÊM ẢNH NÀY VÀO ASSETS**
          image: song.image,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
          imageErrorBuilder: (context, error, stackTrace) {
            return Image.asset('assets/music_placeholder.png', width: 50, height: 50, fit: BoxFit.cover);
          },
        ),
      ),
      /*),*/
      title: Text(song.title, style: const TextStyle(fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis,),
      subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis,),
      trailing: IconButton(
        icon: const Icon(Icons.more_vert_rounded),
        onPressed: () {
          // Xử lý menu ngữ cảnh cho bài hát
        },
      ),
      onTap: onTap,
    );
  }
}

class _PlaylistTile extends StatelessWidget {
  final String playlistName;
  final int numberOfSong;
  final String imagePath;

  const _PlaylistTile({super.key, required this.playlistName, required this.numberOfSong, required this.imagePath}); // Sửa key

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      margin: const EdgeInsets.symmetric(vertical: 6.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: Image.asset(
            imagePath,
            width: 55,
            height: 55,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                width: 55,
                height: 55,
                color: Colors.grey[300],
                child: const Icon(Icons.broken_image, color: Colors.grey),
              );
            },
          ),
        ),
        title: Text(playlistName, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('$numberOfSong bài hát'),
        trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey[600]),
        onTap: () {
          print('Selected playlist: $playlistName');
        },
      ),
    );
  }
}

class _ArtistCircle extends StatelessWidget {
  final String artistName;
  final String imagePath;

  const _ArtistCircle({super.key, required this.artistName, required this.imagePath}); // Sửa key

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 90,
      margin: const EdgeInsets.only(right: 12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 38,
            backgroundColor: Colors.grey[300],
            backgroundImage: AssetImage(imagePath),
            onBackgroundImageError: (exception, stackTrace) {
              print('Error loading artist image: $artistName, $exception');
            },
            // child: (imagePath.isEmpty ...) // Bạn có thể thêm logic hiển thị icon mặc định ở đây nếu cần
          ),
          const SizedBox(height: 8),
          Text(
            artistName,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}